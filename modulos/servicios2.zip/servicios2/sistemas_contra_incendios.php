<?php include 'admin/functions.php';?>
<!--<?php tit_seccion();?>-->
	<div class="inner_content_info_agileits">
		<div class="container">
			<h3 class="heading-agileinfo"><?php tit_seccion();?><span><?php des_seccion();?></span></h3>
            
			<div class="news-agileinfo"> 
				<div class="news-w3row"> 
					<?php servicios($ext);?>                								
                </div>
			</div>
            
		</div>
    </div>
<!--/<?php tit_seccion();?>-->